package prof.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.controller.AbstractAction;
import prof.domain.ClassListVO;
import prof.domain.ScoreViewVO;
import prof.persistence.ClassListDAOMyBatis;
import prof.persistence.ProfessorDAOMyBatis;

public class UpdateScoreAction extends AbstractAction {

	ClassListDAOMyBatis cdao=new ClassListDAOMyBatis();
	
	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		List<ClassListVO> cList=cdao.classByProf(1021);
		//1. 학번, 점수 받아오기
		String sNumStr=req.getParameter("efSnum");
		int sNum=Integer.parseInt(sNumStr);
//		String lNameStr=req.getParameter("efLnum");
//		int lNum=Integer.parseInt(lNameStr);
		String scoreStr=req.getParameter("efScore");
		int score=Integer.parseInt(scoreStr);
		System.out.println("score"+score);
		
		//2. 유효성 체크
//		if(scoreStr==null||scoreStr.trim().isEmpty()) {
//			this.setRedirect(false);
//			this.setViewPage("insertScore.do");
//			return;
//		}
		
		//교번 알아내기
//		HttpSession ses=req.getSession();
//		//ProfessorVO loginUser=(ProfessorVO)ses.getAttribute("loginUser");
//		//int pNum=loginUser.getpNum();//교번

		ProfessorDAOMyBatis dao=new ProfessorDAOMyBatis();
		//성적이 입력되어있는지 확인
		//1. 입력되어있다면 점수만 수정
		ScoreViewVO scoreView=new ScoreViewVO();
//		scoreView.setlNum(lNum);
		scoreView.setsNum(sNum);
		scoreView.setScore(score);
		//System.out.println("lNum: "+scoreVo.getlNum()+", sNum: "+scoreVo.getsNum()+", score: "+scoreVo.getScore());
		dao.updateScore(scoreView);
		System.out.println(score);
		/*
		 * String msg=(n>0)? "��ٱ��� ��� ����":"��� ����"; String loc=(n>0)?
		 * "cart.do":"javascript:history.back()"; String view=CommonUtil.addMsgLoc(req,
		 * msg, loc);
		 */
		
		List<ScoreViewVO> sList=cdao.studentListByClass();
		HttpSession ses = req.getSession();
	    ses.setAttribute("sList", sList);

		String view="insertScore.jsp";
		this.setViewPage(view);
		this.setRedirect(true);

	}

}
