package student.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.controller.AbstractAction;

public class CheckTimeTableAction extends AbstractAction {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("CheckTimeTableAction의 execute()....");
		this.setViewPage("student/CheckTimeTable.jsp");
		this.setRedirect(false);
	}

}
