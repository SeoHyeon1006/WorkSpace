package common.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AdminIndexAction extends AbstractAction {
   
   public void execute(HttpServletRequest req, HttpServletResponse res)
   throws Exception{
      req.setAttribute("msg", "TIS의 페이지입니다.");
      this.setViewPage("/mindex.jsp"); //              
      this.setRedirect(false); 
   }

}/////////////////
